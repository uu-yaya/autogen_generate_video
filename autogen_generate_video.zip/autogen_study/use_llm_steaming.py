from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken
from autogen_ext.models.openai import OpenAIChatCompletionClient
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

# 创建一个使用 qwen 模型的Agent
model_client = OpenAIChatCompletionClient(
    model="qwen-plus",
    api_key=os.getenv("DASHSCOPE_API_KEY"),
    base_url=os.getenv("API_BASE_URL"),
    model_info={
        "vision": True,
        "function_calling": True,
        "json_output": True,
        "family": "unknown",
        "structured_output": False
    },
)

streaming_assistant = AssistantAgent(
    name="assistant",
    model_client=model_client,
    system_message="你是一位得力的助手",
    model_client_stream=True,  # 流式传输模型客户端生成的文本
)


async def main():
    async for message in streaming_assistant.on_messages_stream(
            [TextMessage(content="请说出两个南美洲城市的名字", source="user")],
            cancellation_token=CancellationToken(),
    ):
        print(message)

    # # 使用run_stream()产生同样的效果
    # async for message in streaming_assistant.run_stream(task="Name two cities in North America."):  # type: ignore
    #     print(message)


asyncio.run(main())