from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_agentchat.ui import Console
from autogen_core import CancellationToken
from autogen_ext.models.openai import OpenAIChatCompletionClient
import asyncio
import os
from dotenv import load_dotenv
load_dotenv()

# 定义一个网络搜索工具
async def web_search(query: str) -> str:
    """在网络上查找信息"""
    return "AutoGen 是一个用于构建多代理应用程序的编程框架。"

# 创建一个使用 qwen 模型的Agent
model_client = OpenAIChatCompletionClient(
    model="qwen-plus",
    api_key=os.getenv("DASHSCOPE_API_KEY"),
    base_url=os.getenv("API_BASE_URL"),
    model_info={
        "vision": False,
        "function_calling": True,
        "json_output": True,
        "family": "unknown",
        "structured_output": False
    },
    )

# 创建AssistantAgent
agent = AssistantAgent(
    name="assistant",
    model_client=model_client,
    tools=[web_search],
    system_message="使用工具来解决任务。",
)

"""
AgentChat 提供了一组预设Agent，每个Agent对消息的响应方式各不相同：
- AssistantAgent：是一个内置的Agent，使用大语言模型，并且具有使用工具的能力
- UserProxyAgent： 接受用户输入并将其作为响应返回的代理。
- CodeExecutorAgent： 可以执行代码的代理。
- OpenAIAssistantAgent： 由 OpenAI Assistant 支持的代理，能够使用自定义工具。
- MultimodalWebSurfer： 可以搜索网络并访问网页以获取信息的多模态代理。
- FileSurfer： 可以搜索和浏览本地文件以获取信息的代理。
- VideoSurfer： 可以观看视频以获取信息的代理。
"""

#调用大模型获得响应
async def assistant_run() -> None:
    #on_messages（） 方法来获取代理对给定消息的响应
    response = await agent.on_messages(
        [TextMessage(content="查找关于 AutoGen 的信息", source="user")],
        cancellation_token=CancellationToken(),
    )
    # run() 和 run_stream() ：便捷方法分别调用 on_messages() 和 on_messages_stream()
    # 使用run()方法返回 TaskResult 对象，打印print(response)
    # response = await agent.run(
    #     task = TextMessage(content="查找关于 AutoGen 的信息", source="user"),
    #     cancellation_token=CancellationToken(),
    # )
    print(response.inner_messages)
    print()
    print(response.chat_message)

asyncio.run(assistant_run())

async def assistant_run_stream() -> None:
    await Console(
        # 使用on_messages_stream()
        agent.on_messages_stream(
            [TextMessage(content="查找关于 AutoGen 的信息", source="user")],
            cancellation_token=CancellationToken(),
        )

        # 使用run_stream()
        # agent.run_stream(
        #     task = TextMessage(content="查找关于 AutoGen 的信息", source="user"),
        #     cancellation_token=CancellationToken(),
        # )
    )

asyncio.run(assistant_run_stream())